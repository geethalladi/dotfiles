@org.junit.jupiter.api.Test
@DisplayName("${TEST_NAME")
void ${NAME}() {
  ${BODY}
}